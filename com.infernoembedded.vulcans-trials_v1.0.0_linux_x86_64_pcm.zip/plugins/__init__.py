# SPDX-License-Identifier: GPL-3.0-only
# Copyright (c) 2026 Alastair D'Silva — Vulcan's Trials

"""Vulcan's Trials — KiCad ActionPlugin & IPC Sync Integration.

Registers a toolbar button in KiCad Pcbnew, resolves the vulcans-trials
binary (bundled in PCM package or installed on system), connects to
KiCad IPC socket streaming when available, and launches Vulcan's Trials.
"""

import os
import shutil
import socket
import subprocess
import sys

try:
    import pcbnew
    import wx
    HAS_GUI = True
except ImportError:
    HAS_GUI = False


def find_binary() -> str | None:
    """Resolve the vulcans-trials executable across bundled, PATH, and build locations."""
    is_win = sys.platform.startswith("win")
    exe_name = "vulcans-trials.exe" if is_win else "vulcans-trials"
    plugin_dir = os.path.dirname(os.path.realpath(__file__))

    import platform
    mach = platform.machine().lower()
    arch_dir = "aarch64" if mach in ("arm64", "aarch64") else "x86_64"

    # 1. Bundled inside PCM package (architecture-specific subfolder or flat)
    bundled_candidates = [
        os.path.join(plugin_dir, "bin", arch_dir, exe_name),
        os.path.join(plugin_dir, "bin", exe_name),
        os.path.join(plugin_dir, "..", "bin", arch_dir, exe_name),
        os.path.join(plugin_dir, "..", "bin", exe_name),
        os.path.join(plugin_dir, exe_name),
    ]
    for c in bundled_candidates:
        if c and os.path.isfile(c) and (is_win or os.access(c, os.X_OK)):
            return os.path.abspath(c)

    # 2. Environment variable override
    env_bin = os.environ.get("VULCANS_TRIALS_BIN")
    if env_bin and os.path.isfile(env_bin) and (is_win or os.access(env_bin, os.X_OK)):
        return os.path.abspath(env_bin)

    # 3. System PATH
    path_bin = shutil.which(exe_name) or shutil.which("vulcans-trials")
    if path_bin:
        return os.path.abspath(path_bin)

    # 4. Local workspace / target builds & cargo home
    workspace_candidates = [
        os.path.abspath(os.path.join(plugin_dir, "..", "target", "release", exe_name)),
        os.path.expanduser(f"~/.cargo/bin/{exe_name}"),
        "/usr/local/bin/vulcans-trials",
        "/usr/bin/vulcans-trials",
    ]
    if is_win:
        workspace_candidates.extend([
            os.path.expandvars(r"%LOCALAPPDATA%\vulcans-trials\vulcans-trials.exe"),
            os.path.expandvars(r"%PROGRAMFILES%\vulcans-trials\vulcans-trials.exe"),
        ])

    for c in workspace_candidates:
        if c and os.path.isfile(c) and (is_win or os.access(c, os.X_OK)):
            return os.path.abspath(c)

    return None


def get_ipc_endpoint() -> str | None:
    """Detect available KiCad 9/10 IPC streaming socket or endpoint."""
    # Check environment variable
    env_ipc = os.environ.get("KICAD_IPC_PATH") or os.environ.get("KICAD_IPC_SOCKET")
    if env_ipc:
        return env_ipc

    # Check default Unix domain sockets
    if not sys.platform.startswith("win"):
        pid = os.getpid()
        candidates = [
            "/tmp/kicad/api.sock",
            "/tmp/kicad/kicad.sock",
            f"/tmp/kicad_ipc_{pid}.sock",
            "/tmp/kicad_ipc.sock",
            os.path.expanduser("~/.kicad_ipc.sock"),
        ]
        if "XDG_RUNTIME_DIR" in os.environ:
            candidates.insert(1, os.path.join(os.environ["XDG_RUNTIME_DIR"], "kicad", "api.sock"))
            candidates.insert(2, os.path.join(os.environ["XDG_RUNTIME_DIR"], "kicad", "kicad.sock"))

        for sock in candidates:
            if os.path.exists(sock):
                return sock

    # Check Windows named pipe
    if sys.platform.startswith("win"):
        pipe_name = r"\\.\pipe\kicad_ipc"
        if os.path.exists(pipe_name):
            return pipe_name

    # Check kicad.ipc module if present in KiCad 10
    try:
        import kicad.ipc  # type: ignore
        if hasattr(kicad.ipc, "get_socket_path"):
            return kicad.ipc.get_socket_path()
    except (ImportError, AttributeError):
        pass

    return None


def connect_ipc(endpoint: str | None = None) -> bool:
    """Test connection to KiCad IPC streaming socket."""
    if not endpoint:
        endpoint = get_ipc_endpoint()
    if not endpoint:
        return False

    try:
        if sys.platform.startswith("win") or "://" in endpoint or ":" in endpoint:
            # TCP address host:port
            host, port_str = endpoint.rsplit(":", 1)
            port = int(port_str)
            with socket.create_connection((host, port), timeout=0.5):
                return True
        else:
            # Unix domain socket
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
                s.settimeout(0.5)
                s.connect(endpoint)
                return True
    except Exception:
        # IPC endpoint exists but connection failed or not ready
        return False


def trigger_kicad_revert_ipc(endpoint: str | None = None) -> bool:
    """Send RevertDocument and RefillZones to KiCad over IPC socket if available."""
    if not endpoint:
        endpoint = get_ipc_endpoint()
    if not endpoint:
        return False
    try:
        import ctypes
        libnng = ctypes.CDLL("libnng.so.1")
        class NngSocket(ctypes.Structure):
            _fields_ = [("id", ctypes.c_uint32)]
        sock = NngSocket()
        if libnng.nng_req0_open(ctypes.byref(sock)) != 0:
            return False
        uri = f"ipc://{endpoint}\0".encode("utf-8")
        if libnng.nng_dial(sock, uri, None, 0) != 0:
            libnng.nng_close(sock)
            return False

        def send_cmd(type_url, payload=b"", token=b""):
            hdr = b""
            if token:
                hdr += bytes([10, len(token)]) + token
            client = b"vulcan-plugin-watcher"
            hdr += bytes([18, len(client)]) + client
            u_bytes = type_url.encode("utf-8")
            any_msg = bytes([10, len(u_bytes)]) + u_bytes + bytes([18, len(payload)]) + payload
            req = bytes([10, len(hdr)]) + hdr + bytes([18, len(any_msg)]) + any_msg
            if libnng.nng_send(sock, req, len(req), 0) != 0:
                return 0, b"", b""
            buf_ptr = ctypes.c_void_p()
            buf_len = ctypes.c_size_t()
            if libnng.nng_recv(sock, ctypes.byref(buf_ptr), ctypes.byref(buf_len), 1) != 0:
                return 0, b"", b""
            raw = ctypes.string_at(buf_ptr.value, buf_len.value)
            libnng.nng_free(buf_ptr, buf_len)

            t = b""
            status = 0
            val = b""
            i = 0
            while i < len(raw):
                wb = raw[i]; i += 1
                tag = wb >> 3; wt = wb & 7
                if wt == 0:
                    v = 0; s = 0
                    while True:
                        b = raw[i]; i += 1; v |= (b & 0x7f) << s
                        if not (b & 0x80): break
                        s += 7
                elif wt == 2:
                    l = 0; s = 0
                    while True:
                        b = raw[i]; i += 1; l |= (b & 0x7f) << s
                        if not (b & 0x80): break
                        s += 7
                    chunk = raw[i:i+l]; i += l
                    if tag == 1 and len(chunk) > 2 and chunk[0] == 10:
                        t = chunk[2:2+chunk[1]]
                    elif tag == 2 and len(chunk) >= 2 and chunk[0] == 8:
                        status = chunk[1]
                    elif tag == 3 and len(chunk) > 2:
                        j = 0
                        while j < len(chunk):
                            awb = chunk[j]; j += 1
                            atag = awb >> 3; awt = awb & 7
                            if awt == 2:
                                al = 0; as_shift = 0
                                while True:
                                    ab = chunk[j]; j += 1; al |= (ab & 0x7f) << as_shift
                                    if not (ab & 0x80): break
                                    as_shift += 7
                                if atag == 2: val = chunk[j:j+al]
                                j += al
                            elif awt == 0:
                                while chunk[j] & 0x80: j += 1
                                j += 1
                            else: break
            return status, t, val

        # Ping
        _, tok, _ = send_cmd("type.googleapis.com/kiapi.common.commands.Ping")
        # GetOpenDocuments
        st, tok, resp = send_cmd("type.googleapis.com/kiapi.common.commands.GetOpenDocuments", bytes([8, 3]), tok)
        if st == 1 and resp:
            doc_len = resp[1]
            doc_spec = resp[2:2+doc_len]
            rev_req = bytes([10, len(doc_spec)]) + doc_spec
            rst, tok, _ = send_cmd("type.googleapis.com/kiapi.common.commands.RevertDocument", rev_req, tok)
            if rst == 1:
                send_cmd("type.googleapis.com/kiapi.board.commands.RefillZones", rev_req, tok)
                libnng.nng_close(sock)
                return True
        libnng.nng_close(sock)
    except Exception:
        pass
    return False


def import_ses_with_view_refresh(board, ses_path: str) -> bool:
    """Import a Specctra .ses file into KiCad and force a KIGFX::VIEW R-tree update on all footprints.

    Works around a KiCad 10.0 bug where PCB_EDIT_FRAME::ImportSpecctraSession leaves
    '// Update footprint positions' unimplemented, causing moved footprints to retain stale
    R-tree bounding boxes and disappear when panning the canvas.
    """
    if not HAS_GUI or not board or not os.path.isfile(ses_path):
        return False

    if not pcbnew.ImportSpecctraSES(board, ses_path):
        return False

    # Re-commit footprint positions via BOARD_COMMIT or Refresh so KIGFX::VIEW updates R-tree bounds
    try:
        commit = pcbnew.BOARD_COMMIT(board)
        for fp in board.GetFootprints():
            commit.Modify(fp)
            fp.SetPosition(fp.GetPosition())
            fp.SetOrientation(fp.GetOrientation())
        commit.Push("Refresh Specctra Session Footprint Bounds")
    except Exception:
        pass

    try:
        pcbnew.Refresh()
    except Exception:
        pass

    return True


if HAS_GUI:
    class VulcanBoardWatcher(wx.Timer):
        """Monitors for saved .ses or .kicad_pcb from Vulcan's Trials and updates PCBNEW."""
        def __init__(self, board, pcb_path: str, ses_path: str):
            super().__init__()
            self.board = board
            self.pcb_path = pcb_path
            self.ses_path = ses_path
            self.last_pcb_mtime = os.path.getmtime(pcb_path) if os.path.exists(pcb_path) else 0
            self.last_ses_mtime = os.path.getmtime(ses_path) if os.path.exists(ses_path) else 0

        def Notify(self):
            cur_ses_mtime = os.path.getmtime(self.ses_path) if os.path.exists(self.ses_path) else 0
            cur_pcb_mtime = os.path.getmtime(self.pcb_path) if os.path.exists(self.pcb_path) else 0
            if cur_ses_mtime > self.last_ses_mtime or cur_pcb_mtime > self.last_pcb_mtime:
                self.last_ses_mtime = cur_ses_mtime
                self.last_pcb_mtime = cur_pcb_mtime
                if not trigger_kicad_revert_ipc():
                    if os.path.exists(self.ses_path):
                        import_ses_with_view_refresh(self.board, self.ses_path)
                    try:
                        pcbnew.Refresh()
                    except Exception:
                        pass

    _ACTIVE_WATCHER = None

    class VulcansTrialsPlugin(pcbnew.ActionPlugin):
        def defaults(self):
            self.name = "Vulcan's Trials"
            self.category = "Auto-Place & Auto-Route"
            self.description = "Launch Vulcan's Trials GPU-accelerated auto-placer and auto-router"
            self.show_toolbar_button = True
            self.icon_file_name = os.path.join(os.path.dirname(__file__), "icon.png")

        def Run(self):
            global _ACTIVE_WATCHER
            board = pcbnew.GetBoard()
            board_path = board.GetFileName() if board else ""
            if not board_path or not os.path.exists(board_path):
                wx.MessageBox(
                    "Please save your KiCad board (.kicad_pcb) before launching Vulcan's Trials.",
                    "Vulcan's Trials — InfernoEmbedded",
                    wx.OK | wx.ICON_INFORMATION,
                )
                return

            binary = find_binary()
            if not binary:
                wx.MessageBox(
                    "Could not find 'vulcans-trials' binary.\n\n"
                    "Install the full PCM package containing bundled binaries, or build from source with:\n"
                    "  cargo build --release\n"
                    "or set the VULCANS_TRIALS_BIN environment variable.",
                    "Vulcan's Trials — Binary Not Found",
                    wx.OK | wx.ICON_ERROR,
                )
                return

            ses_path = os.path.splitext(board_path)[0] + ".ses"
            cmd = [binary, "--input", board_path]

            ipc_ep = get_ipc_endpoint()
            if ipc_ep:
                connect_ipc(ipc_ep)
                cmd.extend(["--ipc", ipc_ep])

            # Start watcher in PCBNEW to auto-import / refresh when Vulcan's Trials saves
            try:
                _ACTIVE_WATCHER = VulcanBoardWatcher(board, board_path, ses_path)
                _ACTIVE_WATCHER.Start(1000)
            except Exception:
                pass

            subprocess.Popen(cmd)


try:
    if HAS_GUI:
        VulcansTrialsPlugin().register()
except Exception:
    # Allows safe importing in headless/unit-test environments where KiCad's GUI program is not initialized
    pass

